<?php
// Text
$_['text_title']  = 'Ship Via Movex Courier';
$_['text_weight'] = 'Weight (grams):';